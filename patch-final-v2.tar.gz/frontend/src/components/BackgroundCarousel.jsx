import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';

const BackgroundCarousel = () => {
    const location = useLocation();
    const isAuthPage = ['/login', '/register', '/portal'].some(path => location.pathname.startsWith(path));

    const assets = [
        { type: 'video', src: '/backgrounds/Logo_Animation_With_Smoke_Effect (1).mp4' },
        { type: 'image', src: '/backgrounds/Gemini_Generated_Image_hc4qd9hc4qd9hc4q.png' },
        { type: 'video', src: '/backgrounds/Video_Generation_With_Logo.mp4' },
        { type: 'image', src: '/backgrounds/Gemini_Generated_Image_ujdnipujdnipujdn.png' },
        { type: 'video', src: '/backgrounds/212024_medium.mp4' },
        { type: 'image', src: '/backgrounds/Porsche.jpg' }
    ];

    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentIndex((prev) => (prev + 1) % assets.length);
        }, 12000); // Slightly longer for videos
        return () => clearInterval(interval);
    }, [assets.length]);

    if (isAuthPage) return null;

    return (
        <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            zIndex: -1,
            overflow: 'hidden',
            background: '#000'
        }}>
            {assets.map((asset, idx) => (
                <div
                    key={idx}
                    style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        transition: 'opacity 3s ease-in-out',
                        opacity: idx === currentIndex ? 0.25 : 0,
                        visibility: idx === currentIndex ? 'visible' : 'hidden'
                    }}
                >
                    {asset.type === 'video' ? (
                        <video
                            autoPlay
                            muted
                            loop
                            playsInline
                            style={{
                                width: '100%',
                                height: '100%',
                                objectFit: 'cover'
                            }}
                        >
                            <source src={asset.src} type="video/mp4" />
                        </video>
                    ) : (
                        <div style={{
                            width: '100%',
                            height: '100%',
                            backgroundImage: `url(${asset.src})`,
                            backgroundSize: 'cover',
                            backgroundPosition: 'center'
                        }} />
                    )}
                </div>
            ))}
            {/* Professional Vingette & Mesh Gradient Overlay */}
            <div style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                background: 'var(--mesh-gradient)',
                opacity: 0.4,
                pointerEvents: 'none'
            }} />
            <div style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                background: 'radial-gradient(circle at center, transparent 0%, rgba(0,0,0,0.6) 100%), linear-gradient(to bottom, transparent 0%, #0a0c10 100%)',
                pointerEvents: 'none'
            }} />
        </div>
    );
};

export default BackgroundCarousel;
