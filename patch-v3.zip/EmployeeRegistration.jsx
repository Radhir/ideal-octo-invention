import React, { useState } from 'react';
import api from '../../api/axios';
import { useNavigate } from 'react-router-dom';
import GlassCard from '../../components/GlassCard';
import { UserPlus, ArrowLeft, Save, Shield, DollarSign, Calendar } from 'lucide-react';

const EmployeeRegistration = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        employee_id: '',
        fullName: '',
        nationality: '',
        gender: 'Male',
        dob: '',
        maritalStatus: 'Single',
        department: 'IT & Development',
        role: '',
        manager: '',
        joiningDate: new Date().toISOString().split('T')[0],
        salaryType: 'Monthly',
        baseSalary: '0.00',
        workEmail: '',
        uaeAddress: '',
        uaeMobile: '',
        uaeEmerName: '',
        uaeEmerRel: '',
        uaeEmerPhone: '',
        homeCountry: '',
        homeAddress: '',
        homeMobile: '',
        homeEmerName: '',
        homeEmerRel: '',
        homeEmerPhone: '',
        passportNo: '',
        passportExpiry: '',
        visaUid: '',
        visaExpiry: '',
        skills: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            // Simplified API call for demo - in production this would map to a complex backend model
            await api.post('/hr/api/employees/', formData);
            alert('Personnel Node Secured in Master Database.');
            navigate('/hr');
        } catch (err) {
            console.error(err);
            alert('Failed to register employee. Check network status.');
        }
    };

    const fillDemo = () => {
        setFormData({
            ...formData,
            employee_id: "ES-2026-882",
            fullName: "Ravit Adhir",
            nationality: "Indian",
            department: "Cyber Security",
            role: "Senior Scientist",
            uaeAddress: "Downtown Dubai, Tower 1",
            homeCountry: "India",
            skills: "React, Three.js, LLM Architecture, Security Protocols",
            baseSalary: "15000"
        });
    };

    return (
        <div style={{ padding: '40px 30px', background: '#0a0a0a', minHeight: '100vh', color: '#fff' }}>
            <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '50px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
                    <button
                        onClick={() => navigate('/hr')}
                        style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', padding: '10px', borderRadius: '12px', cursor: 'pointer', color: '#fff' }}
                    >
                        <ArrowLeft size={20} />
                    </button>
                    <div>
                        <div style={{ color: '#b08d57', fontWeight: '900', letterSpacing: '4px', fontSize: '10px', marginBottom: '5px' }}>HUMAN CAPITAL MANAGEMENT</div>
                        <h1 style={{ fontFamily: 'Cinzel, serif', fontSize: '2.5rem', fontWeight: '900', margin: 0 }}>EMPLOYEE ONBOARDING</h1>
                    </div>
                </div>
                <button onClick={fillDemo} style={{ background: 'transparent', border: '1px solid rgba(255,255,255,0.1)', color: '#64748b', padding: '8px 16px', borderRadius: '8px', cursor: 'pointer', fontSize: '12px' }}>
                    AUTO-FILL SIMULATION
                </button>
            </header>

            <form onSubmit={handleSubmit}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '30px', maxWidth: '1200px', margin: '0 auto' }}>

                    {/* section 1: identity */}
                    <GlassCard style={{ padding: '40px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '30px', borderBottom: '1px solid rgba(255,255,255,0.05)', paddingBottom: '20px' }}>
                            <UserPlus size={24} color="#b08d57" />
                            <h3 style={{ fontFamily: 'Cinzel, serif', margin: 0, letterSpacing: '2px' }}>PERSONAL IDENTITY</h3>
                        </div>
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '25px' }}>
                            <FormGroup label="Employee ID" name="employee_id" value={formData.employee_id} onChange={handleChange} required />
                            <FormGroup label="Full Name" name="fullName" value={formData.fullName} onChange={handleChange} required />
                            <FormGroup label="Nationality" name="nationality" value={formData.nationality} onChange={handleChange} />
                            <FormGroup label="Gender" name="gender" type="select" options={['Male', 'Female']} value={formData.gender} onChange={handleChange} />
                            <FormGroup label="Date of Birth" name="dob" type="date" value={formData.dob} onChange={handleChange} />
                            <FormGroup label="Marital Status" name="maritalStatus" type="select" options={['Single', 'Married', 'Divorced']} value={formData.maritalStatus} onChange={handleChange} />
                        </div>
                    </GlassCard>

                    {/* section 2: professional */}
                    <GlassCard style={{ padding: '40px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '30px', borderBottom: '1px solid rgba(255,255,255,0.05)', paddingBottom: '20px' }}>
                            <Shield size={24} color="#b08d57" />
                            <h3 style={{ fontFamily: 'Cinzel, serif', margin: 0, letterSpacing: '2px' }}>PROFESSIONAL DEPLOYMENT</h3>
                        </div>
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '25px' }}>
                            <FormGroup label="Department" name="department" type="select" options={['Cyber Security', 'IT & Development', 'Engineering', 'HR & Admin', 'Sales', 'Executive Office']} value={formData.department} onChange={handleChange} />
                            <FormGroup label="Position / Role" name="role" value={formData.role} onChange={handleChange} />
                            <FormGroup label="Reporting Manager" name="manager" value={formData.manager} onChange={handleChange} />
                            <FormGroup label="Joining Date" name="joiningDate" type="date" value={formData.joiningDate} onChange={handleChange} />
                            <FormGroup label="Salary Type" name="salaryType" type="select" options={['Monthly', 'Daily (Attendance Based)', 'Hourly']} value={formData.salaryType} onChange={handleChange} />
                            <FormGroup label="Base Rate / Salary (AED)" name="baseSalary" type="number" value={formData.baseSalary} onChange={handleChange} />
                            <FormGroup label="Work Email" name="workEmail" type="email" value={formData.workEmail} onChange={handleChange} />
                        </div>
                    </GlassCard>

                    {/* section 3: locations */}
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px' }}>
                        <GlassCard style={{ padding: '30px', borderLeft: '4px solid #b08d57' }}>
                            <h4 style={{ color: '#b08d57', fontSize: '0.8rem', letterSpacing: '3px', marginBottom: '25px' }}>CURRENT LOCATION (UAE)</h4>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                                <FormGroup label="UAE Address" name="uaeAddress" value={formData.uaeAddress} onChange={handleChange} />
                                <FormGroup label="UAE Mobile" name="uaeMobile" value={formData.uaeMobile} onChange={handleChange} />
                                <div style={{ background: 'rgba(255,255,255,0.02)', padding: '20px', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.05)' }}>
                                    <div style={{ fontSize: '10px', color: '#64748b', marginBottom: '15px' }}>EMERGENCY CONTACT (LOCAL)</div>
                                    <div style={{ display: 'grid', gap: '15px' }}>
                                        <input name="uaeEmerName" placeholder="Name" value={formData.uaeEmerName} onChange={handleChange} className="form-control" style={{ border: 'none', background: 'rgba(255,255,255,0.03)' }} />
                                        <input name="uaeEmerRel" placeholder="Relation" value={formData.uaeEmerRel} onChange={handleChange} className="form-control" style={{ border: 'none', background: 'rgba(255,255,255,0.03)' }} />
                                        <input name="uaeEmerPhone" placeholder="Phone" value={formData.uaeEmerPhone} onChange={handleChange} className="form-control" style={{ border: 'none', background: 'rgba(255,255,255,0.03)' }} />
                                    </div>
                                </div>
                            </div>
                        </GlassCard>

                        <GlassCard style={{ padding: '30px', borderLeft: '4px solid #64748b' }}>
                            <h4 style={{ color: '#64748b', fontSize: '0.8rem', letterSpacing: '3px', marginBottom: '25px' }}>HOME COUNTRY ORIGIN</h4>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                                <FormGroup label="Country of Origin" name="homeCountry" value={formData.homeCountry} onChange={handleChange} />
                                <FormGroup label="Home Address" name="homeAddress" value={formData.homeAddress} onChange={handleChange} />
                                <div style={{ background: 'rgba(255,255,255,0.02)', padding: '20px', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.05)' }}>
                                    <div style={{ fontSize: '10px', color: '#64748b', marginBottom: '15px' }}>EMERGENCY CONTACT (HOME)</div>
                                    <div style={{ display: 'grid', gap: '15px' }}>
                                        <input name="homeEmerName" placeholder="Name" value={formData.homeEmerName} onChange={handleChange} className="form-control" style={{ border: 'none', background: 'rgba(255,255,255,0.03)' }} />
                                        <input name="homeEmerRel" placeholder="Relation" value={formData.homeEmerRel} onChange={handleChange} className="form-control" style={{ border: 'none', background: 'rgba(255,255,255,0.03)' }} />
                                        <input name="homeEmerPhone" placeholder="Phone" value={formData.homeEmerPhone} onChange={handleChange} className="form-control" style={{ border: 'none', background: 'rgba(255,255,255,0.03)' }} />
                                    </div>
                                </div>
                            </div>
                        </GlassCard>
                    </div>

                    {/* section 4: compliance & skills */}
                    <GlassCard style={{ padding: '40px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '30px' }}>
                            <Calendar size={24} color="#b08d57" />
                            <h3 style={{ fontFamily: 'Cinzel, serif', margin: 0, letterSpacing: '2px' }}>COMPLIANCE & COMPETENCIES</h3>
                        </div>
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '25px', marginBottom: '30px' }}>
                            <FormGroup label="Passport No" name="passportNo" value={formData.passportNo} onChange={handleChange} />
                            <FormGroup label="Passp. Expiry" name="passportExpiry" type="date" value={formData.passportExpiry} onChange={handleChange} />
                            <FormGroup label="Visa UID" name="visaUid" value={formData.visaUid} onChange={handleChange} />
                            <FormGroup label="Visa Expiry" name="visaExpiry" type="date" value={formData.visaExpiry} onChange={handleChange} />
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                            <label className="form-label" style={{ color: '#b08d57', fontSize: '11px', letterSpacing: '2px' }}>SKILL SET SYNOPSIS</label>
                            <textarea
                                name="skills"
                                className="form-control"
                                rows="3"
                                placeholder="Comma separated competencies..."
                                value={formData.skills}
                                onChange={handleChange}
                                style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.1)', padding: '15px' }}
                            />
                        </div>
                    </GlassCard>

                    <button type="submit" className="btn-primary" style={{ height: '70px', fontSize: '1.2rem', fontWeight: '900', fontFamily: 'Cinzel, serif', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '15px', boxShadow: '0 0 30px rgba(176,141,87,0.2)' }}>
                        <Save size={24} /> SECURE RECORD IN ARCHIVE
                    </button>
                </div>
            </form>
        </div>
    );
};

const FormGroup = ({ label, name, value, onChange, type = 'text', options = [], required = false }) => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <label className="form-label" style={{ color: '#64748b', fontSize: '10px', textTransform: 'uppercase', letterSpacing: '2px', fontWeight: '800' }}>{label}</label>
        {type === 'select' ? (
            <select name={name} className="form-control" value={value} onChange={onChange} required={required}>
                {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
        ) : (
            <input
                name={name}
                type={type}
                className="form-control"
                value={value}
                onChange={onChange}
                required={required}
                style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.05)' }}
            />
        )}
    </div>
);

export default EmployeeRegistration;
